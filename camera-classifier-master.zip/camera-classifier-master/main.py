'''
Camera Classifier v0.1 Alpha
Copyright (c) NeuralNine

Instagram: @neuralnine
YouTube: NeuralNine
Website: www.neuralnine.com
'''

import app

def main():
    app.App(window_title="Camera Classifier v0.1 Alpha")

if __name__ == "__main__":
    main()