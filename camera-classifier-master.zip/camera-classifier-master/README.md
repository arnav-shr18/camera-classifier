# camera-classifier
A Python application that uses camera input to train a SVM to respond to specific actions.
